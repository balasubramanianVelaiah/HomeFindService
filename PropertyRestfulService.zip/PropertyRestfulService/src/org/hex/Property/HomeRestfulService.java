package org.hex.Property;

 

 
import java.util.List;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.Path; 
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.client.Invocation.Builder;


@Path("HomeService")
public class HomeRestfulService { 
	static final String PROPERTY_URI = "http://webservice-takehome-1.spookle.xyz";
	static final String queryParam="property_id";
	
      @Path("/findOwner")
      @GET
      @Produces(MediaType.APPLICATION_JSON)
      public String findHighestHomeValueOwner(@QueryParam("property_id") List<String> property_id) {
    	  JsonObject json=null; 
    	  String result=null;
    	  String failure="Property not found";    	  
    	  double value=0;
    	  double currentValue=0;
    	  String ownerName=null;
    	  String state=null; 	   
    	  
    	  for (String id : property_id) {
    		  Builder builder= ClientBuilder.newClient().target(PROPERTY_URI).path("property").queryParam(queryParam, id).request();
    		  result=builder.get(String.class);
    		  if(result!=null && ! result.contains(failure)) {
    			  json =builder.get(JsonObject.class);
    			  currentValue=json.getInt("value");
    			  JsonObject addressArray=json.getJsonObject("address");    			   
    			  state=addressArray.getString("state");
    			  if("VA".equals(state)) {
    				   if(value==0) {
        				   value=currentValue;
        				   ownerName=json.getString("owner");
        			   }else if(value < currentValue) {
        				   value=currentValue;
        				   ownerName=json.getString("owner");
        			   }
    			   }
    		  }
		    }
    	 if(ownerName!=null) {
    		 result= ownerName;
    	 }else {
    		 result=failure;
    	 }
		 return result;
			 
	  }
      
      
}
		  
	  
